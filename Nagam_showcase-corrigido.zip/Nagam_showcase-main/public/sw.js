// Service worker mínimo, só para satisfazer o critério de instalabilidade
// (PWA) dos navegadores. Não faz cache agressivo de nada — sempre busca a
// rede primeiro — para não quebrar a navegação nem servir versões antigas
// deste showcase, que muda com frequência.
const CACHE_NAME = "nagam-showcase-v1";

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request)),
  );
});
