import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { segments, solutions } from "@/data/catalog";

// TODO(Nagam): troque pelo domínio final de produção assim que ele estiver definido
// (domínio custom ou o *.lovable.app publicado). Mantenha sem barra no final.
const BASE_URL = "https://nagam-showcase.lovable.app";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", changefreq: "weekly", priority: "1.0" },
          { path: "/segmentos", changefreq: "weekly", priority: "0.9" },
          { path: "/solucoes", changefreq: "weekly", priority: "0.9" },
          ...segments.map((s) => ({
            path: `/segmentos/${s.slug}`,
            changefreq: "monthly",
            priority: "0.8",
          })),
          ...solutions.map((s) => ({
            path: `/solucoes/${s.slug}`,
            changefreq: "monthly",
            priority: "0.7",
          })),
        ];

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...entries.map((e) =>
            [
              `  <url>`,
              `    <loc>${BASE_URL}${e.path}</loc>`,
              `    <changefreq>${e.changefreq}</changefreq>`,
              `    <priority>${e.priority}</priority>`,
              `  </url>`,
            ].join("\n"),
          ),
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});