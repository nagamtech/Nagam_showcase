import { useState } from "react";
import { Download, Share, SquarePlus, X } from "lucide-react";
import { toast } from "sonner";
import symbolBlue from "@/assets/nagam-symbol-blue.png.asset.json";
import { useInstallPrompt } from "@/hooks/use-install-prompt";

export function InstallAppButton() {
  const { canInstall, installed, isIos, promptInstall } = useInstallPrompt();
  const [showIosSheet, setShowIosSheet] = useState(false);

  // Já instalado como app: não faz sentido oferecer o botão de novo.
  if (installed) return null;

  // Nem Chrome/Edge/Android (evento nativo) nem iOS (instrução manual) —
  // provavelmente um navegador de desktop sem suporte a instalação. Escondemos
  // em vez de mostrar um botão que não faria nada ao ser clicado.
  if (!canInstall && !isIos) return null;

  const handleClick = async () => {
    if (isIos) {
      setShowIosSheet(true);
      return;
    }
    const outcome = await promptInstall();
    if (outcome === "accepted") toast.success("App instalado! Procure o ícone da Nagam na tela inicial.");
  };

  return (
    <>
      <button
        onClick={handleClick}
        aria-label="Instalar aplicativo Nagam no celular"
        title="Instalar aplicativo"
        className="ml-1 grid h-9 w-9 shrink-0 place-items-center rounded-full border border-border bg-card transition hover:border-accent/50 hover:bg-accent-soft active:scale-95"
      >
        <img
          src={symbolBlue.url}
          alt=""
          aria-hidden="true"
          className="h-5 w-5 object-contain"
        />
      </button>

      {showIosSheet ? (
        <div
          className="animate-fade-in fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 backdrop-blur-sm sm:items-center"
          onClick={() => setShowIosSheet(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <img src={symbolBlue.url} alt="" className="h-8 w-8 object-contain" />
                <p className="text-sm font-semibold">Instalar o app da Nagam</p>
              </div>
              <button
                onClick={() => setShowIosSheet(false)}
                aria-label="Fechar"
                className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-muted-foreground transition hover:bg-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <ol className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-accent-soft text-[10px] font-bold text-accent">
                  1
                </span>
                <span className="flex items-center gap-1.5">
                  Toque no ícone de compartilhar <Share className="h-3.5 w-3.5" /> na barra do Safari
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-accent-soft text-[10px] font-bold text-accent">
                  2
                </span>
                <span className="flex items-center gap-1.5">
                  Escolha <strong className="text-foreground">"Adicionar à Tela de Início"</strong>{" "}
                  <SquarePlus className="h-3.5 w-3.5" />
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-accent-soft text-[10px] font-bold text-accent">
                  3
                </span>
                <span>Toque em "Adicionar" — pronto, o app fica na sua tela inicial</span>
              </li>
            </ol>
            <p className="mt-4 flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Download className="h-3.5 w-3.5" /> Funciona só no Safari do iPhone/iPad (limitação da Apple).
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}
